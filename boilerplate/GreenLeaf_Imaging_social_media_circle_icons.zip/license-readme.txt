Icons made by graphic and web designer Ariel Lepor of GreenLeaf Imaging - www.greenleafimaging.com

Feel free to use these icons on websites, projects, or other materials, no attribution required. However, you may not sell them, copy them into your own icon set without attribution, nor may you distribute this set without this license.

I've saved the icons out in PNG in 32px, and 128px sizes. I've also included the vector source in both SVG and PDF if you want to edit them, add color, make the logos transparent (instead of white), or whatever. If you don't have a vector graphics editor, a good free one is Inkscape (http://inkscape.org/).

Included are the following 65 social media icons:
Facebook, Twitter, Google+, Path, MySpace, Last.fm, Spotify, Skout, Foursquare, Pinterest, Instagram, Photobucket, Google Picasa, Flickr, SmugMug, YouTube, Vimeo, SoundCloud, Vine, Tumblr, Blogger, Wordpress, Drupal, Evernote, Blog (generic), FeedBurner, RSS, Email (generic), StumbleUpon, Digg, Delicious, Technorati, Reddit, Forrst, deviantART, Behance, Dribbble, Google, Yahoo!, Bing, OpenID, Wikipedia, Apple App Store, Google Play, Microsoft Windows, Linux, LinkedIn, iTunes, Yelp, Amazon.com, Etsy, eBay, PayPal, DropBox, Google Drive, Contact (generic), Google Talk, Google Hangouts, Skype, Chat bubble (generic), Heart (generic), Bookmark (generic), Share (generic), Print (generic), Creative Commons.

The copyrights and trademarks of any logos are owned by their respective copyright and trademark holders.